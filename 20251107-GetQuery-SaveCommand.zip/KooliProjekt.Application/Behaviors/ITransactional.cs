﻿namespace KooliProjekt.Application.Behaviors
{
    public interface ITransactional
    {
    }
}