﻿namespace KooliProjekt.Application.Infrastructure.Results
{
    public class LookupItem : LookupItem<int>
    {
    }
}
